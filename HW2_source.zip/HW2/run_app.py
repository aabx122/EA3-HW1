"""Launch the Spring-Damper Energy Explorer."""

from spring_damper.app import main


if __name__ == "__main__":
    main()
