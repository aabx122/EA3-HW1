# Spring Damper Energy Explorer

This folder contains the complete Python implementation for Homework 2. The application models a massless rigid connector attached to a spring and damper in parallel. It shows the connector motion and tracks where the applied work goes: spring energy, damping dissipation, or energy returned to the actuator.

## What the application includes

- Six bounded applied-force families: constant, sinusoidal, square wave, decaying transient, smooth step, and finite pulse.
- Linear and hardening cubic springs.
- Linear and power-law dampers.
- User-defined initial spring extension.
- Animated spring-damper schematic with a time slider.
- Force, extension, velocity, work, stored energy, dissipation, and energy-residual plots.
- Up to six overlaid runs for studying changes in `k`, `b`, the force function, and nonlinear parameters.
- CSV data export and PNG or PDF plot export.

## Physical model

The connector is assumed to have no mass. Its force balance is therefore

```text
F(t) = Fs(x) + Fd(v),    v = dx/dt
```

For a linear spring, `Fs = kx`. The hardening option uses `Fs = kx + k3*x^3`. A linear damper uses `Fd = bv`, while the power-law option uses `Fd = b*sign(v)*abs(v)^n`.

The program integrates extension and the two cumulative energy rates

```text
dWin/dt = Fv
dEd/dt  = Fd*v
```

and computes spring energy from its constitutive law. The diagnostic residual is

```text
energy residual = Win - change in spring energy - Ed
```

It should remain close to zero. Applied work may decrease when the spring returns energy to the actuator; damping dissipation cannot decrease for the passive damping laws used here.

## Run from Python

Use a 64-bit Python distribution that includes Tkinter. Python 3.11 or 3.12 is recommended for the smoothest packaging experience.

### Windows

```powershell
cd "path\to\HW2"
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python run_app.py
```

### macOS or Linux

```bash
cd "/path/to/HW2"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_app.py
```

On macOS, the Homebrew build of Python may omit Tkinter. If `import tkinter` fails, install a Python distribution that includes Tcl/Tk, such as the installer from python.org.

## Suggested classroom workflow

1. Start with **Baseline oscillation** and run the simulation.
2. Move the time slider or select **Play** to connect motion with the plotted values.
3. Read the Work and energy tab and verify that applied work is split between spring-energy change and damping dissipation.
4. Select **Add comparison**.
5. Change one parameter, such as `k` or `b`, rerun, and add the new case.
6. Use Compare runs to identify the effect of that single change.
7. Try **Pulse and relaxation** and **Release stored energy** to see energy enter and leave the spring.
8. Export a CSV if numerical values are needed for a report.

## Run the tests

The tests use Python's built-in `unittest` package.

```bash
cd HW2
python -m unittest discover -s tests -v
python -m compileall -q spring_damper run_app.py tests
```

The suite checks force boundedness, constitutive-law consistency, equilibrium, initial stored energy, nonlinear response, CSV structure, and numerical energy balance.

## Build the required Windows executable

PyInstaller does not cross-compile Windows programs from macOS. Build the `.exe` on a Windows computer:

1. Install 64-bit Python 3.11 from [python.org](https://www.python.org/downloads/windows/) and keep the Tcl/Tk component selected.
2. Copy this entire `HW2` folder to that computer.
3. Double-click `build_windows.bat`, or run it from Command Prompt.
4. Wait for the tests and packaging step to finish.
5. Submit `dist\SpringDamperTeachingModule.exe` together with `docs\Spring_Damper_Teaching_Module_Guide.docx`.

The build script creates an isolated environment, installs the pinned dependency ranges, runs the tests, and invokes the included PyInstaller specification. Building on Windows is required because the PyInstaller bootloader and bundled libraries are platform-specific.

## File guide

```text
HW2/
  run_app.py                              application entry point
  spring_damper/model.py                  physics and energy calculations
  spring_damper/app.py                    graphical interface
  tests/                                  automated tests
  docs/Spring_Damper_Teaching_Module_Guide.docx
                                           supporting submission document
  reference/assignment_prompt.png         supplied assignment image
  build_windows.bat                       Windows build command
  SpringDamperTeachingModule.spec         PyInstaller recipe
  requirements*.txt                       Python dependencies
```

## Assumptions and numerical notes

- The connector, spring, and damper are one-dimensional.
- The connector is massless, so this is a first-order Kelvin-Voigt response rather than a mass-spring-damper vibration model.
- The spring and damper are passive. `k`, `b`, the power exponent, and the cubic spring coefficient must remain in their validated ranges.
- A fourth-order Runge-Kutta method integrates the state. The program automatically adds internal time steps when the material relaxation time is short compared with the displayed sample spacing.
- Square waves and pulse edges are discontinuous, so tiny local numerical residuals may appear near their switching times. The Energy tab displays the residual instead of hiding it.
