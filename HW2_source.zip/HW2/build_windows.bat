@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo Python Launcher was not found. Install 64-bit Python 3.11 or newer from python.org.
    exit /b 1
)

if not exist .venv (
    py -3.11 -m venv .venv
    if errorlevel 1 exit /b 1
)

call .venv\Scripts\activate.bat
python -c "import tkinter; print('Tkinter check passed')"
if errorlevel 1 (
    echo Tkinter is missing. Reinstall Python and select the Tcl/Tk component.
    exit /b 1
)

python -m pip install --upgrade pip
if errorlevel 1 exit /b 1
python -m pip install -r requirements.txt -r requirements-dev.txt
if errorlevel 1 exit /b 1

python -m unittest discover -s tests -v
if errorlevel 1 exit /b 1

python -m PyInstaller --clean --noconfirm SpringDamperTeachingModule.spec
if errorlevel 1 exit /b 1

echo.
echo Build complete:
echo %CD%\dist\SpringDamperTeachingModule.exe
endlocal
