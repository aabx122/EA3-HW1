"""Create the schematic, equation, and example plot used in the supporting guide."""

from pathlib import Path
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from spring_damper.model import (  # noqa: E402
    DamperLaw,
    ForceConfig,
    ForceKind,
    SimulationConfig,
    SpringLaw,
    simulate,
)


OUT = Path(__file__).resolve().parent / "figures"
OUT.mkdir(parents=True, exist_ok=True)

NAVY = "#15324B"
BLUE = "#2A6F97"
TEAL = "#2A9D8F"
ORANGE = "#E07A3F"
MUTED = "#657786"
GRID = "#D9E0E4"


def make_schematic() -> None:
    fig, axis = plt.subplots(figsize=(9, 2.8), dpi=180)
    axis.set_xlim(0, 10)
    axis.set_ylim(0, 4)
    axis.axis("off")

    wall_x = 1.0
    connector_x = 7.8
    axis.plot([wall_x, wall_x], [0.45, 3.55], color=NAVY, lw=4)
    for y in np.linspace(0.6, 3.4, 9):
        axis.plot([0.72, 1.0], [y - 0.18, y + 0.08], color=MUTED, lw=1.3)

    spring_y = 2.75
    axis.plot([wall_x, 1.6], [spring_y, spring_y], color=NAVY, lw=1.8)
    xs = np.linspace(1.6, connector_x - 0.3, 15)
    ys = np.full_like(xs, spring_y)
    ys[1:-1:2] += 0.27
    ys[2:-1:2] -= 0.27
    axis.plot(xs, ys, color=BLUE, lw=2.1)
    axis.plot([connector_x - 0.3, connector_x], [spring_y, spring_y], color=NAVY, lw=1.8)

    damper_y = 1.2
    axis.plot([wall_x, 2.0], [damper_y, damper_y], color=NAVY, lw=1.8)
    axis.add_patch(plt.Rectangle((2.0, 0.82), 1.55, 0.76, fill=False, edgecolor=TEAL, lw=2))
    axis.plot([3.25, 3.25], [0.9, 1.5], color=TEAL, lw=2.5)
    axis.plot([3.25, connector_x], [damper_y, damper_y], color=NAVY, lw=1.8)

    axis.plot([connector_x, connector_x], [0.75, 3.2], color=NAVY, lw=4)
    axis.annotate("", xy=(9.15, 2.0), xytext=(connector_x, 2.0), arrowprops=dict(arrowstyle="-|>", lw=2.4, color=ORANGE))
    axis.text(8.45, 2.22, "$F(t)$", color=ORANGE, fontsize=13, weight="bold", ha="center")
    axis.text(4.5, 3.35, "spring", color=BLUE, fontsize=11, ha="center")
    axis.text(4.5, 0.48, "damper", color=TEAL, fontsize=11, ha="center")
    axis.text(1.0, 3.78, "fixed wall", color=MUTED, fontsize=9, ha="center")
    axis.text(connector_x, 0.4, "massless connector", color=MUTED, fontsize=9, ha="center")
    fig.savefig(OUT / "system_schematic.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def make_equations() -> None:
    equation_sets = {
        "force_balance.png": r"$F(t)=F_s(x)+F_d(\dot{x}),\qquad \dot{x}=v$",
        "constitutive_laws.png": r"$F_s=kx+k_3x^3,\quad U_s=\frac{1}{2}kx^2+\frac{1}{4}k_3x^4,\quad F_d=b\,\mathrm{sgn}(v)|v|^n$",
        "energy_balance.png": r"$W_{in}(t)=\Delta U_s(t)+E_d(t),\quad W_{in}=\int_0^t Fv\,dt,\quad E_d=\int_0^t F_dv\,dt$",
    }
    for filename, equation in equation_sets.items():
        fig = plt.figure(figsize=(9, 0.75), dpi=220, facecolor="white")
        fig.text(0.5, 0.5, equation, ha="center", va="center", fontsize=16, color="#111111")
        fig.savefig(OUT / filename, bbox_inches="tight", pad_inches=0.08, facecolor="white")
        plt.close(fig)


def make_energy_example() -> None:
    result = simulate(
        SimulationConfig(
            force=ForceConfig(kind=ForceKind.PULSE, offset=0.0, amplitude=10.0, pulse_start=1.0, pulse_duration=2.5),
            spring=SpringLaw(k=14.0),
            damper=DamperLaw(b=3.0),
            duration=8.0,
            samples=1401,
        )
    )
    fig, axes = plt.subplots(2, 1, figsize=(9, 5), dpi=180, sharex=True, gridspec_kw={"height_ratios": [3, 1]})
    axes[0].plot(result.time, result.input_work, label="Applied work", color=BLUE, lw=2)
    axes[0].plot(result.time, result.stored_energy_change, label="Spring energy change", color=TEAL, lw=1.8)
    axes[0].plot(result.time, result.dissipated_energy, label="Damping dissipation", color=ORANGE, lw=1.8)
    axes[0].set_ylabel("Energy (J)")
    axes[0].legend(frameon=False, ncol=3, fontsize=9)
    axes[0].set_title("Pulse loading and relaxation", loc="left", color=NAVY, weight="bold")
    axes[1].plot(result.time, result.balance_error, color="#C94C4C", lw=1.2)
    axes[1].axhline(0, color=MUTED, lw=0.8)
    axes[1].set_ylabel("Residual (J)")
    axes[1].set_xlabel("Time (s)")
    for axis in axes:
        axis.grid(True, color=GRID, lw=0.7)
        axis.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(OUT / "energy_example.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    make_schematic()
    make_equations()
    make_energy_example()
