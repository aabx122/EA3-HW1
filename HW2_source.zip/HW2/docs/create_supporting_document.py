"""Generate the supporting Word document for the teaching module."""

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_ALIGN_VERTICAL, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


HERE = Path(__file__).resolve().parent
FIGURES = HERE / "figures"
OUTPUT = HERE / "Spring_Damper_Teaching_Module_Guide.docx"

BLACK = "000000"
NAVY = "15324B"
LIGHT_BLUE = "EAF2F7"
PALE = "F5F7F8"
BORDER = "D9D9D9"
MUTED = "657786"


def set_cell_shading(cell, fill: str) -> None:
    properties = cell._tc.get_or_add_tcPr()
    shading = properties.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        properties.append(shading)
    shading.set(qn("w:fill"), fill)


def set_cell_borders(cell, color: str = BORDER, size: str = "6") -> None:
    properties = cell._tc.get_or_add_tcPr()
    borders = properties.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        properties.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = "w:" + edge
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:color"), color)


def set_cell_margins(cell, top=100, start=120, bottom=100, end=120) -> None:
    properties = cell._tc.get_or_add_tcPr()
    margins = properties.first_child_found_in("w:tcMar")
    if margins is None:
        margins = OxmlElement("w:tcMar")
        properties.append(margins)
    for key, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = margins.find(qn(f"w:{key}"))
        if node is None:
            node = OxmlElement(f"w:{key}")
            margins.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def style_run(run, size=10.8, bold=False, color=BLACK, italic=False) -> None:
    run.font.name = "Arial"
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), "Arial")
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), "Arial")
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = RGBColor.from_string(color)


def style_paragraph(paragraph, after=6, before=0, line=1.08) -> None:
    paragraph.paragraph_format.space_after = Pt(after)
    paragraph.paragraph_format.space_before = Pt(before)
    paragraph.paragraph_format.line_spacing = line


def remove_paragraph_borders(paragraph_or_style) -> None:
    """Remove borders inherited from Word's built-in title formatting."""

    if hasattr(paragraph_or_style, "_p"):
        properties = paragraph_or_style._p.get_or_add_pPr()
    else:
        properties = paragraph_or_style.element.get_or_add_pPr()
    borders = properties.find(qn("w:pBdr"))
    if borders is not None:
        properties.remove(borders)


def add_body(document, text: str, after=7) -> None:
    paragraph = document.add_paragraph()
    style_paragraph(paragraph, after=after, line=1.1)
    style_run(paragraph.add_run(text), size=10.8)


def add_bullet(document, text: str) -> None:
    paragraph = document.add_paragraph(style="List Bullet")
    style_paragraph(paragraph, after=4, line=1.05)
    for run in paragraph.runs:
        style_run(run, size=10.6)
    if not paragraph.runs:
        style_run(paragraph.add_run(text), size=10.6)
    else:
        paragraph.runs[0].text = text


def add_numbered(document, text: str) -> None:
    paragraph = document.add_paragraph(style="List Number")
    style_paragraph(paragraph, after=5, line=1.05)
    style_run(paragraph.add_run(text), size=10.6)


def add_heading(document, text: str, level=1) -> None:
    paragraph = document.add_heading(text, level=level)
    paragraph.paragraph_format.keep_with_next = True
    paragraph.paragraph_format.space_before = Pt(11 if level == 1 else 8)
    paragraph.paragraph_format.space_after = Pt(5)
    for run in paragraph.runs:
        style_run(run, size=15 if level == 1 else 12, bold=True, color=BLACK)


def add_image(document, filename: str, width: float, caption: str | None = None) -> None:
    paragraph = document.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.keep_with_next = bool(caption)
    paragraph.paragraph_format.space_after = Pt(3)
    paragraph.add_run().add_picture(str(FIGURES / filename), width=Inches(width))
    if caption:
        cap = document.add_paragraph()
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        cap.paragraph_format.space_after = Pt(8)
        style_run(cap.add_run(caption), size=9, italic=True, color=MUTED)


def add_table(document, headers, rows, widths) -> None:
    table = document.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for index, header in enumerate(headers):
        cell = table.rows[0].cells[index]
        cell.width = Inches(widths[index])
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        set_cell_shading(cell, NAVY)
        set_cell_borders(cell)
        set_cell_margins(cell)
        paragraph = cell.paragraphs[0]
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        style_paragraph(paragraph, after=0, line=1.0)
        style_run(paragraph.add_run(header), size=9.5, bold=True, color="FFFFFF")
    for row_index, values in enumerate(rows):
        cells = table.add_row().cells
        for column, value in enumerate(values):
            cell = cells[column]
            cell.width = Inches(widths[column])
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
            set_cell_borders(cell)
            set_cell_margins(cell)
            if row_index % 2:
                set_cell_shading(cell, PALE)
            paragraph = cell.paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT if column else WD_ALIGN_PARAGRAPH.CENTER
            style_paragraph(paragraph, after=0, line=1.0)
            style_run(paragraph.add_run(str(value)), size=9.2)
    document.add_paragraph().paragraph_format.space_after = Pt(1)


def configure_document(document: Document) -> None:
    section = document.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.68)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.78)
    section.right_margin = Inches(0.78)

    styles = document.styles
    normal = styles["Normal"]
    normal.font.name = "Arial"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
    normal.font.size = Pt(10.8)
    normal.font.color.rgb = RGBColor.from_string(BLACK)
    for name in ("Title", "Subtitle", "Heading 1", "Heading 2"):
        style = styles[name]
        style.font.name = "Arial"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Arial")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Arial")
        style.font.color.rgb = RGBColor.from_string(BLACK)
        remove_paragraph_borders(style)


def add_footer(document: Document) -> None:
    footer = document.sections[0].footer
    paragraph = footer.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    style_run(paragraph.add_run("Spring Damper Energy Explorer  |  GEN ENG 205-3"), size=8.5, color=MUTED)


def build_document() -> None:
    document = Document()
    configure_document(document)
    add_footer(document)

    title = document.add_paragraph(style="Title")
    remove_paragraph_borders(title)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_after = Pt(4)
    style_run(title.add_run("Spring Damper Energy Explorer"), size=24, bold=True, color=BLACK)

    subtitle = document.add_paragraph(style="Subtitle")
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.paragraph_format.space_after = Pt(12)
    style_run(subtitle.add_run("Supporting Guide for the Teaching Module Challenge"), size=12, color=MUTED)

    add_body(
        document,
        "I built this application to show the energy bookkeeping in a one-dimensional spring and damper connected in parallel. The program links the connector motion to applied work, spring energy, and damping loss on the same timeline. Its comparison view also lets a user change one parameter at a time and see how that choice changes the response.",
        after=8,
    )
    add_image(document, "system_schematic.png", 6.85, "Figure 1  Parallel spring and damper connected to a massless rigid connector")

    add_heading(document, "Purpose and Learning Goal")
    add_body(
        document,
        "The main learning goal is to make the energy transfer visible. When the external force moves the connector, part of its work changes the energy stored in the spring and part is converted to heat by the damper. A pre-stretched spring can also return energy, so applied work is allowed to decrease even though damping dissipation always increases.",
    )
    add_table(
        document,
        ("User choice", "What the application reveals"),
        (
            ("Applied force", "How load shape and time scale change motion and energy flow"),
            ("Spring law and k", "How stiffness changes extension and stored energy"),
            ("Damper law and b", "How resistance changes response speed and dissipation"),
            ("Initial extension", "How energy already stored at t = 0 can be released"),
        ),
        (1.75, 4.75),
    )

    document.add_page_break()
    add_heading(document, "Physical Model")
    add_body(
        document,
        "The right connector is assumed to have no mass. It cannot support an unbalanced force, so the applied force must equal the spring force plus the damper force at every instant. The spring and damper share the same extension and velocity because they connect the same two points.",
    )
    add_image(document, "force_balance.png", 5.9)

    add_heading(document, "Constitutive Laws", level=2)
    add_body(
        document,
        "The default laws are linear: spring force is kx and damper force is bv. The optional models keep the elements passive while showing nonlinear behavior. The hardening spring adds a positive cubic term, and the power-law damper changes how strongly damping grows with speed.",
    )
    add_image(document, "constitutive_laws.png", 6.65)

    add_heading(document, "Energy Accounting", level=2)
    add_body(
        document,
        "The simulation integrates connector velocity, applied power, and dissipated power with the same fourth-order Runge-Kutta steps. Spring energy comes directly from the spring law. I plot spring-energy change relative to the initial state, because that makes the balance valid when the spring begins with nonzero extension.",
    )
    add_image(document, "energy_balance.png", 6.55)
    add_body(
        document,
        "The Work and energy tab includes the residual Wᵢₙ − ΔUₛ − Eᴅ. A small residual confirms that the numerical solution follows the energy balance. It is a diagnostic rather than another form of energy.",
    )

    add_heading(document, "Allowed Applied Forces", level=2)
    add_table(
        document,
        ("Family", "Behavior", "Teaching use"),
        (
            ("Constant", "Remains finite", "Observe exponential relaxation to equilibrium"),
            ("Sinusoidal", "Oscillates about an offset", "Study repeated storage and release"),
            ("Square wave", "Switches between two finite levels", "Compare abrupt loading and unloading"),
            ("Decaying transient", "Approaches the offset", "Watch a temporary load fade away"),
            ("Smooth step", "Approaches a finite level", "Compare loading time with b/k"),
            ("Finite pulse", "Returns to the offset", "Separate loading from relaxation"),
        ),
        (1.25, 2.15, 3.1),
    )

    document.add_page_break()
    add_heading(document, "Using the Application")
    add_numbered(document, "Choose a classroom preset or select an applied-force function. Only functions that remain finite are offered.")
    add_numbered(document, "Enter the force parameters, spring law, damper law, initial extension, duration, and output sample count.")
    add_numbered(document, "Select Run simulation. Invalid or nonpassive parameter values are rejected with a specific message.")
    add_numbered(document, "Use the System tab slider or Play button to connect the moving connector with the current numerical values.")
    add_numbered(document, "Open Dynamics to inspect force, extension, and velocity on a common time axis.")
    add_numbered(document, "Open Work and energy to compare applied work, spring-energy change, damping dissipation, and the numerical residual.")
    add_numbered(document, "Select Add comparison, change one input, rerun, and add the new case. Up to six cases can be overlaid.")
    add_numbered(document, "Export the active result as CSV or save a plot as PNG or PDF when a figure is needed in a report.")

    add_heading(document, "Reading the Results")
    add_image(document, "energy_example.png", 6.55, "Figure 2  A force pulse stores energy, then the damper dissipates it during relaxation")
    add_body(
        document,
        "In Figure 2, applied work rises while the pulse moves the connector. Some of that work appears temporarily as spring energy. After the pulse ends, the spring returns toward its undeformed state; its energy decreases while cumulative damping dissipation continues to rise. At the end, nearly all input work has become dissipated energy.",
    )
    add_bullet(document, "A larger extension at the same force usually indicates a smaller spring constant.")
    add_bullet(document, "A slower approach to equilibrium usually indicates more damping relative to stiffness.")
    add_bullet(document, "A falling applied-work curve means the system is returning energy to the external force source.")
    add_bullet(document, "A rising dissipated-energy curve is expected for every passive damper option in the application.")

    document.add_page_break()
    add_heading(document, "Suggested Investigations")
    add_table(
        document,
        ("Investigation", "Change", "Keep fixed", "Expected observation"),
        (
            ("Spring stiffness", "Increase k", "Force and b", "Smaller extension and a shorter b/k relaxation time"),
            ("Damping", "Increase b", "Force and k", "Slower motion and dissipation spread over more time"),
            ("Force time scale", "Change frequency or τ", "Material laws", "Different lag between load and deformation"),
            ("Preload release", "Set x₀ > 0 with F = 0", "k and b", "Stored energy falls as damping dissipation rises"),
            ("Hardening spring", "Increase k₃", "Small-signal k", "Large extensions are suppressed more strongly"),
            ("Power-law damper", "Change n", "b and force", "Speed dependence changes, especially at larger forces"),
        ),
        (1.35, 1.35, 1.35, 2.45),
    )
    add_body(
        document,
        "For a clean comparison, I would change one parameter at a time and add each result to the Compare runs tab. The extension plot shows the change in motion, while the dissipation plot shows the corresponding energy cost.",
    )

    add_heading(document, "Assumptions and Limits")
    add_bullet(document, "The system is one-dimensional, and both elements experience the same connector motion.")
    add_bullet(document, "The connector is massless. The model therefore has no inertia and is not a vibrating mass-spring-damper system.")
    add_bullet(document, "The spring and damper laws are passive. Negative stiffness, negative damping, and a softening cubic coefficient are not allowed.")
    add_bullet(document, "The program uses numerical integration. It automatically adds internal steps when the material relaxation time is short, and it reports the remaining energy residual.")
    add_bullet(document, "A square wave and pulse have instantaneous edges in the mathematical definition. Small residual spikes near those edges are numerical effects, not additional stored energy.")

    add_heading(document, "Files for Submission")
    add_body(
        document,
        "The Windows build script creates dist\\SpringDamperTeachingModule.exe. The executable should be submitted with this guide. The source folder also contains the physics tests, PyInstaller specification, dependency list, assignment image, and a README with build instructions.",
    )

    document.save(OUTPUT)
    print(OUTPUT)


if __name__ == "__main__":
    build_document()
