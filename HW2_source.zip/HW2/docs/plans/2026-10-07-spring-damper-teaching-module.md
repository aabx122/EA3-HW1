# Spring Damper Teaching Module Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a Python desktop teaching module that simulates a massless spring and damper in parallel, exposes bounded applied-force and constitutive-law choices, and makes displacement and energy flow easy to inspect and compare.

**Architecture:** A testable physics module owns force laws, constitutive laws, numerical integration, and energy accounting. A Tkinter and Matplotlib desktop interface consumes that module, animates the connector, plots dynamics and energy, supports parameter-comparison runs, and exports results. Supporting scripts package the application on Windows, while an English Word guide explains the model and classroom use.

**Tech Stack:** Python 3.11 or newer, NumPy, Matplotlib, Tkinter, unittest, python-docx, PyInstaller

---

## File Structure

- `HW2/spring_damper/model.py`: physical laws, validation, integration, and result arrays.
- `HW2/spring_damper/app.py`: desktop user interface, plots, animation, comparison, and exports.
- `HW2/spring_damper/__init__.py`: public package interface.
- `HW2/run_app.py`: development entry point.
- `HW2/tests/test_model.py`: model and energy-balance regression tests.
- `HW2/requirements.txt`: runtime dependencies.
- `HW2/requirements-dev.txt`: testing and packaging dependencies.
- `HW2/SpringDamperTeachingModule.spec`: deterministic PyInstaller configuration.
- `HW2/build_windows.bat`: one-command Windows executable build.
- `HW2/README.md`: setup, use, testing, and packaging instructions.
- `HW2/docs/Spring_Damper_Teaching_Module_Guide.docx`: supporting assignment document.
- `HW2/reference/assignment_prompt.png`: retained copy of the supplied assignment image.

### Task 1: Establish the validated physical model

**Files:**
- Create: `HW2/spring_damper/model.py`
- Create: `HW2/spring_damper/__init__.py`
- Test: `HW2/tests/test_model.py`

- [ ] **Step 1: Write failing tests for bounded force families and parameter validation**

```python
def test_supported_forces_stay_within_expected_bounds():
    for kind in ForceKind:
        cfg = ForceConfig(kind=kind, offset=2.0, amplitude=3.0)
        values = np.array([evaluate_force(t, cfg) for t in np.linspace(0, 20, 1001)])
        assert np.all(np.isfinite(values))
        assert values.min() >= -1.000001
        assert values.max() <= 5.000001
```

- [ ] **Step 2: Run the focused test and verify that imports fail before implementation**

Run: `python3 -m unittest tests.test_model.ForceLawTests -v`

Expected: failure because `spring_damper.model` does not yet exist.

- [ ] **Step 3: Implement bounded force definitions and constitutive laws**

```python
class ForceKind(str, Enum):
    CONSTANT = "Constant"
    SINUSOIDAL = "Sinusoidal"
    SQUARE = "Square wave"
    DECAYING = "Decaying transient"
    STEP_RESPONSE = "Smooth step"
    PULSE = "Finite pulse"

def spring_force(x, law):
    return law.k * x + law.k3 * x**3

def spring_energy(x, law):
    return 0.5 * law.k * x**2 + 0.25 * law.k3 * x**4

def damper_velocity(force, law):
    return np.sign(force) * (abs(force) / law.b) ** (1.0 / law.exponent)
```

- [ ] **Step 4: Run force-law tests and confirm all force families are finite and bounded**

Run: `python3 -m unittest tests.test_model.ForceLawTests -v`

Expected: all tests pass.

### Task 2: Integrate motion and all energy channels

**Files:**
- Modify: `HW2/spring_damper/model.py`
- Modify: `HW2/tests/test_model.py`

- [ ] **Step 1: Write failing equilibrium and energy-conservation tests**

```python
def test_constant_force_approaches_linear_equilibrium():
    result = simulate(SimulationConfig(duration=12.0, force=ForceConfig(offset=8.0)))
    self.assertAlmostEqual(result.extension[-1], 8.0 / result.config.spring.k, places=3)

def test_energy_balance_is_small_relative_to_work_scale():
    result = simulate(SimulationConfig())
    scale = max(1.0, np.max(np.abs(result.input_work)))
    self.assertLess(np.max(np.abs(result.balance_error)) / scale, 2e-4)
```

- [ ] **Step 2: Run the simulation tests and verify that `simulate` is missing**

Run: `python3 -m unittest tests.test_model.SimulationTests -v`

Expected: failure for an undefined simulation API.

- [ ] **Step 3: Implement RK4 integration of extension, input work, and dissipation**

```python
def rates(t, state, config):
    x = state[0]
    applied = evaluate_force(t, config.force)
    elastic = spring_force(x, config.spring)
    velocity = damper_velocity(applied - elastic, config.damper)
    return np.array([velocity, applied * velocity, (applied - elastic) * velocity])
```

Use the same RK4 stages for all three state variables. Calculate stored-energy change exactly from the spring potential, and define the diagnostic residual as `input_work - stored_energy_change - dissipated_energy`.

- [ ] **Step 4: Run the complete model suite**

Run: `python3 -m unittest discover -s tests -v`

Expected: all force, equilibrium, nonlinear-law, initial-energy, and balance tests pass.

### Task 3: Build the interactive desktop interface

**Files:**
- Create: `HW2/spring_damper/app.py`
- Create: `HW2/run_app.py`

- [ ] **Step 1: Build grouped inputs with defaults and validation**

```python
sections = {
    "Applied force F(t)": ("force_type", "offset", "amplitude", "frequency", "phase"),
    "Spring law": ("spring_type", "k", "k3", "initial_extension"),
    "Damper law": ("damper_type", "b", "exponent"),
    "Simulation": ("duration", "samples"),
}
```

Only show fields used by the selected force and material models. Reject nonpositive damping, duration, sample count, or power-law exponent with a specific message.

- [ ] **Step 2: Connect the Run button to the tested model**

```python
def run_simulation(self):
    config = self.read_config()
    self.result = simulate(config)
    self.update_all_plots(self.result)
    self.set_time_index(0)
```

- [ ] **Step 3: Add a schematic, timeline controls, and linked readouts**

Draw a wall, spring, damper, connector, and force arrow on a Tkinter canvas. A time slider and Play button update the geometry and current force, extension, velocity, stored energy, dissipated energy, and input work.

- [ ] **Step 4: Add Dynamics and Energy plot tabs**

The Dynamics tab shows applied force, extension, and velocity against time. The Energy tab shows cumulative input work, change in spring energy, damping dissipation, and the balance residual with a zero reference line.

- [ ] **Step 5: Add instructional text inside the application**

Explain `F = Fs + Fd`, the selected force law, the selected constitutive laws, the effect of initial extension, sign conventions, and how to interpret negative input work.

### Task 4: Add parameter-study and export workflows

**Files:**
- Modify: `HW2/spring_damper/app.py`

- [ ] **Step 1: Add named comparison runs**

```python
def add_comparison(self):
    label = self.describe_run(self.result.config)
    self.comparison_runs.append((label, self.result))
    self.redraw_comparison()
```

Plot extension and cumulative dissipated energy for up to six runs, retain a readable legend, and provide a Clear comparisons action.

- [ ] **Step 2: Add CSV and PNG export**

Export columns for time, applied force, extension, velocity, spring force, damper force, absolute stored energy, stored-energy change, input work, dissipation, and balance residual. Export the active plot at publication resolution.

- [ ] **Step 3: Add preset classroom experiments**

Provide at least a sinusoidal baseline, a smooth load step, a pulse and relaxation case, and a nonlinear-material case.

### Task 5: Verify the interface without relying on a display server

**Files:**
- Create: `HW2/tests/test_exports.py`
- Modify: `HW2/spring_damper/app.py`

- [ ] **Step 1: Separate CSV formatting from the file dialog**

```python
def result_rows(result):
    return zip(result.time, result.applied_force, result.extension, result.velocity, ...)
```

- [ ] **Step 2: Test CSV column names and row count**

Run: `python3 -m unittest discover -s tests -v`

Expected: the export has one header row and exactly one row per simulated time sample.

- [ ] **Step 3: Compile every Python source file**

Run: `python3 -m compileall -q spring_damper run_app.py tests`

Expected: exit code 0 and no syntax errors.

### Task 6: Prepare reproducible Windows packaging

**Files:**
- Create: `HW2/requirements.txt`
- Create: `HW2/requirements-dev.txt`
- Create: `HW2/SpringDamperTeachingModule.spec`
- Create: `HW2/build_windows.bat`

- [ ] **Step 1: Pin compatible major dependency ranges**

```text
numpy>=2.0,<3
matplotlib>=3.9,<4
```

- [ ] **Step 2: Configure PyInstaller for a windowed one-file executable**

The spec names the output `SpringDamperTeachingModule`, includes Matplotlib data files, uses `run_app.py` as the entry point, and disables the console window.

- [ ] **Step 3: Add a Windows build script**

```bat
py -3.11 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt -r requirements-dev.txt
python -m PyInstaller --clean --noconfirm SpringDamperTeachingModule.spec
```

- [ ] **Step 4: Document the platform constraint**

State that PyInstaller must build the `.exe` on Windows and that the finished file appears at `dist\SpringDamperTeachingModule.exe`.

### Task 7: Write the user and submission documentation

**Files:**
- Create: `HW2/README.md`
- Create: `HW2/docs/create_supporting_document.py`
- Create: `HW2/docs/Spring_Damper_Teaching_Module_Guide.docx`

- [ ] **Step 1: Write a concise repository guide**

Cover environment setup, launching, interaction, tests, CSV export, Windows packaging, file layout, and troubleshooting.

- [ ] **Step 2: Author the supporting Word document in the student's voice**

Use the sections `Purpose and Learning Goal`, `Physical Model`, `Using the Application`, `Reading the Results`, `Suggested Investigations`, and `Assumptions and Limits`. Explain equations in plain language and connect each display to the assignment goals.

- [ ] **Step 3: Render the document and inspect every page image**

Run the bundled `render_docx.py` into `HW2/docs/.rendered` and verify no clipping, overlap, broken tables, awkward page breaks, or missing glyphs.

- [ ] **Step 4: Revise and re-render until the document is clean**

Expected: all pages use Letter portrait layout, readable 11-point body text, black headings, consistent spacing, and a compact parameter table with visible light-gray borders.

### Task 8: Complete acceptance testing

**Files:**
- Modify as needed based on test results.

- [ ] **Step 1: Run all unit tests and compilation checks**

Run: `python3 -m unittest discover -s tests -v && python3 -m compileall -q spring_damper run_app.py tests`

Expected: all tests pass and all modules compile.

- [ ] **Step 2: Run numerical smoke tests for every force and material combination**

Expected: every supported combination returns finite arrays, nonnegative cumulative dissipation up to numerical tolerance, and a small normalized energy residual.

- [ ] **Step 3: Launch the GUI for a manual smoke test when a display is available**

Confirm Run, reset, presets, timeline playback, comparison, CSV export, PNG export, and close behavior.

- [ ] **Step 4: Confirm assignment coverage**

Verify that the final package lets a user select only bounded force functions, choose linear or nonlinear spring and damper laws, set initial extension, observe position and every energy channel over time, and compare the effects of `k`, `b`, force shape, and nonlinear parameters.
