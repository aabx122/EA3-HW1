"""Tests for the spring-damper teaching module."""
