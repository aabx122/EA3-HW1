import unittest
from dataclasses import replace

import numpy as np

from spring_damper.model import (
    DamperKind,
    DamperLaw,
    ForceConfig,
    ForceKind,
    SimulationConfig,
    SpringKind,
    SpringLaw,
    ValidationError,
    damper_force,
    damper_velocity,
    evaluate_force,
    simulate,
    spring_energy,
    spring_force,
)


class ForceLawTests(unittest.TestCase):
    def test_every_force_family_is_finite(self):
        times = np.linspace(0, 20, 2001)
        for kind in ForceKind:
            with self.subTest(kind=kind):
                cfg = ForceConfig(
                    kind=kind,
                    offset=2.0,
                    amplitude=3.0,
                    frequency=0.7,
                    tau=2.5,
                    pulse_start=3.0,
                    pulse_duration=4.0,
                )
                values = evaluate_force(times, cfg)
                self.assertTrue(np.all(np.isfinite(values)))
                self.assertGreaterEqual(float(values.min()), -1.000001)
                self.assertLessEqual(float(values.max()), 5.000001)

    def test_force_families_that_settle_reach_a_constant(self):
        for kind in (ForceKind.CONSTANT, ForceKind.DECAYING, ForceKind.SMOOTH_STEP, ForceKind.PULSE):
            with self.subTest(kind=kind):
                cfg = ForceConfig(kind=kind, offset=2.0, amplitude=3.0, tau=1.0)
                late = np.asarray(evaluate_force(np.array([100.0, 101.0]), cfg))
                self.assertAlmostEqual(float(late[0]), float(late[1]), places=10)


class ConstitutiveLawTests(unittest.TestCase):
    def test_spring_energy_derivative_matches_force(self):
        law = SpringLaw(kind=SpringKind.HARDENING, k=8.0, k3=2.5)
        x = 0.7
        dx = 1e-6
        derivative = (spring_energy(x + dx, law) - spring_energy(x - dx, law)) / (2 * dx)
        self.assertAlmostEqual(derivative, spring_force(x, law), places=6)

    def test_power_law_damper_inverse(self):
        law = DamperLaw(kind=DamperKind.POWER_LAW, b=2.3, exponent=1.7)
        forces = np.array([-5.0, -0.2, 0.0, 0.4, 7.5])
        recovered = damper_force(damper_velocity(forces, law), law)
        np.testing.assert_allclose(recovered, forces, rtol=1e-12, atol=1e-12)

    def test_invalid_material_constants_are_rejected(self):
        with self.assertRaises(ValidationError):
            simulate(SimulationConfig(spring=SpringLaw(k=0.0)))
        with self.assertRaises(ValidationError):
            simulate(SimulationConfig(damper=DamperLaw(b=-1.0)))


class SimulationTests(unittest.TestCase):
    def test_constant_force_approaches_linear_equilibrium(self):
        config = SimulationConfig(
            force=ForceConfig(kind=ForceKind.CONSTANT, offset=8.0, amplitude=0.0),
            spring=SpringLaw(k=10.0),
            damper=DamperLaw(b=2.0),
            duration=5.0,
            samples=1201,
        )
        result = simulate(config)
        self.assertAlmostEqual(result.extension[-1], 0.8, places=6)
        self.assertAlmostEqual(result.velocity[-1], 0.0, places=6)

    def test_initial_spring_energy_is_accounted_for(self):
        config = SimulationConfig(
            force=ForceConfig(kind=ForceKind.CONSTANT, offset=0.0, amplitude=0.0),
            spring=SpringLaw(k=10.0),
            damper=DamperLaw(b=2.0),
            initial_extension=0.5,
            duration=4.0,
            samples=1201,
        )
        result = simulate(config)
        self.assertAlmostEqual(result.stored_energy[0], 1.25, places=12)
        self.assertAlmostEqual(result.dissipated_energy[-1], 1.25, places=5)
        self.assertAlmostEqual(result.input_work[-1], 0.0, places=12)

    def test_energy_balance_is_small_for_each_force_family(self):
        base = SimulationConfig(duration=8.0, samples=1601)
        for kind in ForceKind:
            with self.subTest(kind=kind):
                result = simulate(replace(base, force=replace(base.force, kind=kind)))
                self.assertLess(result.normalized_balance_error, 2e-5)
                self.assertGreaterEqual(float(result.dissipated_energy.min()), -1e-10)

    def test_nonlinear_combination_is_finite_and_balanced(self):
        config = SimulationConfig(
            force=ForceConfig(kind=ForceKind.SINUSOIDAL, offset=1.0, amplitude=7.0, frequency=0.8),
            spring=SpringLaw(kind=SpringKind.HARDENING, k=9.0, k3=18.0),
            damper=DamperLaw(kind=DamperKind.POWER_LAW, b=3.0, exponent=1.4),
            initial_extension=-0.2,
            duration=7.0,
            samples=1801,
        )
        result = simulate(config)
        for values in (
            result.extension,
            result.velocity,
            result.stored_energy,
            result.input_work,
            result.dissipated_energy,
        ):
            self.assertTrue(np.all(np.isfinite(values)))
        self.assertLess(result.normalized_balance_error, 2e-4)


if __name__ == "__main__":
    unittest.main()
