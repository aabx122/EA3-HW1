import csv
import io
import unittest

from spring_damper.model import CSV_COLUMNS, SimulationConfig, result_rows, simulate


class ExportTests(unittest.TestCase):
    def test_csv_schema_and_row_count(self):
        result = simulate(SimulationConfig(duration=1.0, samples=101))
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(CSV_COLUMNS)
        writer.writerows(result_rows(result))
        rows = list(csv.reader(io.StringIO(buffer.getvalue())))
        self.assertEqual(tuple(rows[0]), CSV_COLUMNS)
        self.assertEqual(len(rows), 102)
        self.assertTrue(all(len(row) == len(CSV_COLUMNS) for row in rows))


if __name__ == "__main__":
    unittest.main()
