"""Spring-damper teaching module."""

from .model import (
    CSV_COLUMNS,
    DamperKind,
    DamperLaw,
    ForceConfig,
    ForceKind,
    SimulationConfig,
    SimulationResult,
    SpringKind,
    SpringLaw,
    ValidationError,
    evaluate_force,
    force_equation,
    result_rows,
    simulate,
)

__all__ = [
    "CSV_COLUMNS",
    "DamperKind",
    "DamperLaw",
    "ForceConfig",
    "ForceKind",
    "SimulationConfig",
    "SimulationResult",
    "SpringKind",
    "SpringLaw",
    "ValidationError",
    "evaluate_force",
    "force_equation",
    "result_rows",
    "simulate",
]
