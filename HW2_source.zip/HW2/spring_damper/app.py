"""Tkinter desktop interface for the spring-damper teaching module."""

from __future__ import annotations

import csv
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure

from .model import (
    CSV_COLUMNS,
    DamperKind,
    DamperLaw,
    ForceConfig,
    ForceKind,
    SimulationConfig,
    SimulationResult,
    SpringKind,
    SpringLaw,
    ValidationError,
    force_equation,
    result_rows,
    simulate,
)


COLORS = {
    "navy": "#15324B",
    "blue": "#2A6F97",
    "teal": "#2A9D8F",
    "orange": "#E07A3F",
    "gold": "#D4A72C",
    "red": "#C94C4C",
    "ink": "#25313C",
    "muted": "#657786",
    "paper": "#F5F7F8",
    "white": "#FFFFFF",
    "grid": "#D9E0E4",
}


PRESETS = {
    "Baseline oscillation": {
        "force_kind": ForceKind.SINUSOIDAL.value,
        "offset": "3", "amplitude": "5", "frequency": "0.5", "phase": "0",
        "tau": "1.5", "pulse_start": "1", "pulse_duration": "2",
        "spring_kind": SpringKind.LINEAR.value, "k": "12", "k3": "0",
        "damper_kind": DamperKind.LINEAR.value, "b": "3", "exponent": "1",
        "initial_extension": "0", "duration": "10", "samples": "1601",
    },
    "Smooth loading": {
        "force_kind": ForceKind.SMOOTH_STEP.value,
        "offset": "0", "amplitude": "8", "frequency": "0.5", "phase": "0",
        "tau": "1.2", "pulse_start": "1", "pulse_duration": "2",
        "spring_kind": SpringKind.LINEAR.value, "k": "10", "k3": "0",
        "damper_kind": DamperKind.LINEAR.value, "b": "4", "exponent": "1",
        "initial_extension": "0", "duration": "10", "samples": "1601",
    },
    "Pulse and relaxation": {
        "force_kind": ForceKind.PULSE.value,
        "offset": "0", "amplitude": "10", "frequency": "0.5", "phase": "0",
        "tau": "1.5", "pulse_start": "1", "pulse_duration": "2.5",
        "spring_kind": SpringKind.LINEAR.value, "k": "14", "k3": "0",
        "damper_kind": DamperKind.LINEAR.value, "b": "3", "exponent": "1",
        "initial_extension": "0", "duration": "9", "samples": "1601",
    },
    "Release stored energy": {
        "force_kind": ForceKind.CONSTANT.value,
        "offset": "0", "amplitude": "0", "frequency": "0.5", "phase": "0",
        "tau": "1.5", "pulse_start": "1", "pulse_duration": "2",
        "spring_kind": SpringKind.LINEAR.value, "k": "10", "k3": "0",
        "damper_kind": DamperKind.LINEAR.value, "b": "2", "exponent": "1",
        "initial_extension": "0.6", "duration": "4", "samples": "1201",
    },
    "Nonlinear materials": {
        "force_kind": ForceKind.SINUSOIDAL.value,
        "offset": "1", "amplitude": "8", "frequency": "0.6", "phase": "0",
        "tau": "1.5", "pulse_start": "1", "pulse_duration": "2",
        "spring_kind": SpringKind.HARDENING.value, "k": "8", "k3": "16",
        "damper_kind": DamperKind.POWER_LAW.value, "b": "3", "exponent": "1.4",
        "initial_extension": "0", "duration": "10", "samples": "1801",
    },
}


class SpringDamperApp(tk.Tk):
    """Interactive teaching application."""

    def __init__(self) -> None:
        super().__init__()
        self.title("Spring-Damper Energy Explorer")
        self.geometry("1400x880")
        self.minsize(1160, 720)
        self.configure(bg=COLORS["paper"])

        self.result: SimulationResult | None = None
        self.comparison_runs: list[tuple[str, SimulationResult]] = []
        self.playing = False
        self.play_job: str | None = None
        self.current_index = 0
        self.variables: dict[str, tk.StringVar] = {}
        self.entries: dict[str, ttk.Entry] = {}
        self.readout_labels: dict[str, ttk.Label] = {}

        self._configure_style()
        self._build_layout()
        self._bind_shortcuts()
        self.apply_preset("Baseline oscillation", run=True)

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        available = style.theme_names()
        if "clam" in available:
            style.theme_use("clam")
        style.configure("TFrame", background=COLORS["paper"])
        style.configure("Panel.TFrame", background=COLORS["white"])
        style.configure("TLabel", background=COLORS["paper"], foreground=COLORS["ink"], font=("Arial", 10))
        style.configure("Panel.TLabel", background=COLORS["white"], foreground=COLORS["ink"], font=("Arial", 10))
        style.configure("Title.TLabel", background=COLORS["paper"], foreground=COLORS["navy"], font=("Arial", 19, "bold"))
        style.configure("Subtitle.TLabel", background=COLORS["paper"], foreground=COLORS["muted"], font=("Arial", 10))
        style.configure("Header.TLabel", background=COLORS["navy"], foreground=COLORS["white"], font=("Arial", 10, "bold"), padding=(8, 6))
        style.configure("Value.TLabel", background=COLORS["white"], foreground=COLORS["navy"], font=("Arial", 13, "bold"))
        style.configure("TLabelframe", background=COLORS["paper"], bordercolor=COLORS["grid"], relief="solid")
        style.configure("TLabelframe.Label", background=COLORS["paper"], foreground=COLORS["navy"], font=("Arial", 10, "bold"))
        style.configure("Accent.TButton", background=COLORS["blue"], foreground="white", font=("Arial", 10, "bold"), padding=(10, 7))
        style.map("Accent.TButton", background=[("active", COLORS["navy"]), ("pressed", COLORS["navy"])])
        style.configure("TButton", font=("Arial", 10), padding=(8, 6))
        style.configure("TNotebook", background=COLORS["paper"], borderwidth=0)
        style.configure("TNotebook.Tab", font=("Arial", 10, "bold"), padding=(14, 7))

    def _build_layout(self) -> None:
        header = ttk.Frame(self, padding=(16, 12, 16, 8))
        header.pack(fill="x")
        ttk.Label(header, text="Spring-Damper Energy Explorer", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            header,
            text="Explore how applied work becomes elastic energy or heat in a parallel spring-damper system.",
            style="Subtitle.TLabel",
        ).pack(anchor="w", pady=(2, 0))

        body = ttk.Panedwindow(self, orient="horizontal")
        body.pack(fill="both", expand=True, padx=14, pady=(0, 8))
        controls = self._build_control_panel(body)
        content = self._build_content_panel(body)
        body.add(controls, weight=0)
        body.add(content, weight=1)

        self.status_var = tk.StringVar(value="Ready")
        status = ttk.Label(self, textvariable=self.status_var, anchor="w", padding=(14, 6), style="Panel.TLabel")
        status.pack(fill="x", side="bottom")

    def _build_control_panel(self, parent: ttk.Panedwindow) -> ttk.Frame:
        shell = ttk.Frame(parent, width=355)
        shell.pack_propagate(False)
        canvas = tk.Canvas(shell, width=340, background=COLORS["paper"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(shell, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas, padding=(4, 2, 10, 10))
        inner.bind("<Configure>", lambda _event: canvas.configure(scrollregion=canvas.bbox("all")))
        window = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(window, width=event.width))
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        preset_box = ttk.LabelFrame(inner, text="Classroom preset", padding=10)
        preset_box.pack(fill="x", pady=(0, 8))
        self.preset_var = tk.StringVar(value="Baseline oscillation")
        preset_combo = ttk.Combobox(preset_box, textvariable=self.preset_var, values=list(PRESETS), state="readonly")
        preset_combo.pack(fill="x")
        preset_combo.bind("<<ComboboxSelected>>", lambda _event: self.apply_preset(self.preset_var.get(), run=True))

        force = ttk.LabelFrame(inner, text="Applied force F(t)", padding=10)
        force.pack(fill="x", pady=8)
        self._add_combo(force, "force_kind", "Function", [kind.value for kind in ForceKind])
        self._add_entry(force, "offset", "Offset F₀ (N)")
        self._add_entry(force, "amplitude", "Amplitude A (N)")
        self._add_entry(force, "frequency", "Frequency f (Hz)")
        self._add_entry(force, "phase", "Phase φ (deg)")
        self._add_entry(force, "tau", "Time constant τ (s)")
        self._add_entry(force, "pulse_start", "Pulse start (s)")
        self._add_entry(force, "pulse_duration", "Pulse duration (s)")
        self.force_equation_var = tk.StringVar()
        ttk.Label(force, textvariable=self.force_equation_var, wraplength=305, foreground=COLORS["blue"]).grid(
            row=8, column=0, columnspan=2, sticky="w", pady=(8, 0)
        )

        spring = ttk.LabelFrame(inner, text="Spring", padding=10)
        spring.pack(fill="x", pady=8)
        self._add_combo(spring, "spring_kind", "Constitutive law", [kind.value for kind in SpringKind])
        self._add_entry(spring, "k", "Linear constant k (N/m)")
        self._add_entry(spring, "k3", "Cubic constant k₃ (N/m³)")
        self._add_entry(spring, "initial_extension", "Initial extension x₀ (m)")

        damper = ttk.LabelFrame(inner, text="Damper", padding=10)
        damper.pack(fill="x", pady=8)
        self._add_combo(damper, "damper_kind", "Constitutive law", [kind.value for kind in DamperKind])
        self._add_entry(damper, "b", "Damping constant b")
        self._add_entry(damper, "exponent", "Power exponent n")

        simulation = ttk.LabelFrame(inner, text="Simulation", padding=10)
        simulation.pack(fill="x", pady=8)
        self._add_entry(simulation, "duration", "Duration (s)")
        self._add_entry(simulation, "samples", "Output samples")

        actions = ttk.Frame(inner)
        actions.pack(fill="x", pady=(10, 4))
        ttk.Button(actions, text="Run simulation", style="Accent.TButton", command=self.run_simulation).pack(fill="x")
        row = ttk.Frame(actions)
        row.pack(fill="x", pady=(6, 0))
        ttk.Button(row, text="Add comparison", command=self.add_comparison).pack(side="left", fill="x", expand=True, padx=(0, 3))
        ttk.Button(row, text="Clear", command=self.clear_comparisons).pack(side="left", fill="x", expand=True, padx=(3, 0))
        row2 = ttk.Frame(actions)
        row2.pack(fill="x", pady=(6, 0))
        ttk.Button(row2, text="Export CSV", command=self.export_csv).pack(side="left", fill="x", expand=True, padx=(0, 3))
        ttk.Button(row2, text="Save plot", command=self.export_plot).pack(side="left", fill="x", expand=True, padx=(3, 0))

        self.variables["force_kind"].trace_add("write", lambda *_args: self._update_field_states())
        self.variables["spring_kind"].trace_add("write", lambda *_args: self._update_field_states())
        self.variables["damper_kind"].trace_add("write", lambda *_args: self._update_field_states())
        return shell

    def _add_entry(self, parent: ttk.LabelFrame, name: str, label: str) -> None:
        row = parent.grid_size()[1]
        variable = tk.StringVar()
        self.variables[name] = variable
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=3)
        entry = ttk.Entry(parent, textvariable=variable, width=13)
        entry.grid(row=row, column=1, sticky="ew", pady=3)
        parent.columnconfigure(1, weight=1)
        self.entries[name] = entry

    def _add_combo(self, parent: ttk.LabelFrame, name: str, label: str, values: list[str]) -> None:
        row = parent.grid_size()[1]
        variable = tk.StringVar()
        self.variables[name] = variable
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=3)
        combo = ttk.Combobox(parent, textvariable=variable, values=values, state="readonly", width=16)
        combo.grid(row=row, column=1, sticky="ew", pady=3)
        parent.columnconfigure(1, weight=1)

    def _build_content_panel(self, parent: ttk.Panedwindow) -> ttk.Frame:
        frame = ttk.Frame(parent, style="Panel.TFrame")
        self.notebook = ttk.Notebook(frame)
        self.notebook.pack(fill="both", expand=True)

        overview = ttk.Frame(self.notebook, style="Panel.TFrame", padding=12)
        dynamics = ttk.Frame(self.notebook, style="Panel.TFrame")
        energy = ttk.Frame(self.notebook, style="Panel.TFrame")
        comparison = ttk.Frame(self.notebook, style="Panel.TFrame")
        guide = ttk.Frame(self.notebook, style="Panel.TFrame", padding=18)
        self.notebook.add(overview, text="System")
        self.notebook.add(dynamics, text="Dynamics")
        self.notebook.add(energy, text="Work and energy")
        self.notebook.add(comparison, text="Compare runs")
        self.notebook.add(guide, text="How to read it")

        self._build_overview(overview)
        self.dynamics_figure, self.dynamics_canvas = self._make_figure(dynamics, 3, 1)
        self.energy_figure, self.energy_canvas = self._make_figure(energy, 2, 1, height_ratios=[3, 1])
        self.compare_figure, self.compare_canvas = self._make_figure(comparison, 2, 1)
        self._build_guide(guide)
        return frame

    def _make_figure(self, parent: ttk.Frame, rows: int, cols: int, **gridspec_kw):
        figure = Figure(figsize=(9, 6.5), dpi=100, facecolor=COLORS["white"], constrained_layout=True)
        figure.subplots(rows, cols, gridspec_kw=gridspec_kw or None)
        canvas = FigureCanvasTkAgg(figure, master=parent)
        toolbar = NavigationToolbar2Tk(canvas, parent, pack_toolbar=False)
        toolbar.update()
        toolbar.pack(side="bottom", fill="x")
        canvas.get_tk_widget().pack(fill="both", expand=True)
        return figure, canvas

    def _build_overview(self, parent: ttk.Frame) -> None:
        self.schematic = tk.Canvas(parent, height=280, background=COLORS["white"], highlightthickness=1, highlightbackground=COLORS["grid"])
        self.schematic.pack(fill="x")
        self.schematic.bind("<Configure>", lambda _event: self._draw_schematic(self.current_index))

        timeline = ttk.Frame(parent, style="Panel.TFrame", padding=(0, 12, 0, 8))
        timeline.pack(fill="x")
        self.play_button = ttk.Button(timeline, text="▶ Play", command=self.toggle_play)
        self.play_button.pack(side="left", padx=(0, 8))
        self.time_var = tk.DoubleVar(value=0)
        self.time_scale = ttk.Scale(timeline, from_=0, to=100, variable=self.time_var, command=self._timeline_changed)
        self.time_scale.pack(side="left", fill="x", expand=True)
        self.time_label = ttk.Label(timeline, text="t = 0.000 s", style="Panel.TLabel", width=15, anchor="e")
        self.time_label.pack(side="right", padx=(8, 0))

        cards = ttk.Frame(parent, style="Panel.TFrame")
        cards.pack(fill="both", expand=True)
        card_specs = (
            ("force", "Applied force", "N"),
            ("extension", "Extension", "m"),
            ("velocity", "Velocity", "m/s"),
            ("stored", "Spring energy", "J"),
            ("dissipated", "Dissipated", "J"),
            ("work", "Applied work", "J"),
        )
        for index, (key, title, unit) in enumerate(card_specs):
            box = tk.Frame(cards, bg=COLORS["white"], highlightthickness=1, highlightbackground=COLORS["grid"], padx=12, pady=10)
            box.grid(row=index // 3, column=index % 3, sticky="nsew", padx=5, pady=5)
            tk.Label(box, text=title, bg=COLORS["white"], fg=COLORS["muted"], font=("Arial", 10)).pack(anchor="w")
            value = ttk.Label(box, text=f"0.000 {unit}", style="Value.TLabel")
            value.pack(anchor="w", pady=(4, 0))
            self.readout_labels[key] = value
        for column in range(3):
            cards.columnconfigure(column, weight=1)
        for row in range(2):
            cards.rowconfigure(row, weight=1)

        self.balance_var = tk.StringVar(value="Energy balance residual: --")
        ttk.Label(parent, textvariable=self.balance_var, style="Panel.TLabel", foreground=COLORS["muted"]).pack(anchor="w", pady=(8, 0))

    def _build_guide(self, parent: ttk.Frame) -> None:
        text = tk.Text(
            parent,
            wrap="word",
            relief="flat",
            background=COLORS["white"],
            foreground=COLORS["ink"],
            font=("Arial", 11),
            padx=18,
            pady=14,
            spacing1=3,
            spacing3=8,
        )
        text.pack(fill="both", expand=True)
        text.tag_configure("title", font=("Arial", 18, "bold"), foreground=COLORS["navy"], spacing3=12)
        text.tag_configure("heading", font=("Arial", 12, "bold"), foreground=COLORS["blue"], spacing1=12, spacing3=5)
        sections = [
            ("title", "How this model works\n"),
            ("body", "The right connector is treated as massless. At every instant, the applied force is shared by the parallel spring and damper: F(t) = Fs(x) + Fd(v). The spring force depends on extension x, while the damper force depends on velocity v. This relation determines v, and integrating v gives x over time.\n"),
            ("heading", "Reading the energy plot\n"),
            ("body", "Applied work is the time integral of Fv. The change in spring energy is measured from the initial state, so it can be negative when a pre-stretched spring releases energy. Dissipated energy is the integral of Fd v and cannot decrease for the supported passive dampers. The curves should satisfy W_in = ΔU_s + E_d. The lower panel shows the small numerical residual in this equation.\n"),
            ("heading", "Studying k and b\n"),
            ("body", "Increase k to make the spring carry a given force at a smaller extension. Increase b to slow the connector motion and spread dissipation over a longer time. Use Add comparison after each run to place cases on the same axes. Change one parameter at a time when you want a clear cause-and-effect comparison.\n"),
            ("heading", "Studying the applied force\n"),
            ("body", "The available forces are constant, periodic, or settle to a finite constant. A pulse is useful for observing loading followed by relaxation. A sinusoid shows repeated storage and release. A smooth step separates the effect of the force time scale from the material time scale b/k.\n"),
            ("heading", "Sign convention\n"),
            ("body", "Rightward extension, velocity, and force are positive. Applied work can fall when the connector moves against the applied force; this means energy is returned to the external actuator. Damping dissipation still increases because the damper always removes mechanical energy.\n"),
        ]
        for tag, content in sections:
            text.insert("end", content, tag)
        text.configure(state="disabled")

    def _bind_shortcuts(self) -> None:
        self.bind("<Control-r>", lambda _event: self.run_simulation())
        self.bind("<Control-s>", lambda _event: self.export_csv())
        self.protocol("WM_DELETE_WINDOW", self._close)

    def apply_preset(self, name: str, run: bool = False) -> None:
        values = PRESETS.get(name)
        if not values:
            return
        self.preset_var.set(name)
        for key, value in values.items():
            self.variables[key].set(value)
        self._update_field_states()
        if run:
            self.run_simulation()

    def _set_entry_state(self, names: tuple[str, ...], enabled: bool) -> None:
        for name in names:
            self.entries[name].configure(state="normal" if enabled else "disabled")

    def _update_field_states(self) -> None:
        try:
            force_kind = ForceKind(self.variables["force_kind"].get())
            spring_kind = SpringKind(self.variables["spring_kind"].get())
            damper_kind = DamperKind(self.variables["damper_kind"].get())
        except ValueError:
            return

        periodic = force_kind in (ForceKind.SINUSOIDAL, ForceKind.SQUARE)
        transient = force_kind in (ForceKind.DECAYING, ForceKind.SMOOTH_STEP)
        pulse = force_kind is ForceKind.PULSE
        amplitude = force_kind is not ForceKind.CONSTANT
        self._set_entry_state(("amplitude",), amplitude)
        self._set_entry_state(("frequency", "phase"), periodic)
        self._set_entry_state(("tau",), transient)
        self._set_entry_state(("pulse_start", "pulse_duration"), pulse)
        self._set_entry_state(("k3",), spring_kind is SpringKind.HARDENING)
        self._set_entry_state(("exponent",), damper_kind is DamperKind.POWER_LAW)
        try:
            self.force_equation_var.set(force_equation(self._read_force_config()))
        except (ValueError, ValidationError):
            self.force_equation_var.set("Enter valid force parameters to view F(t).")

    def _number(self, name: str, label: str) -> float:
        try:
            value = float(self.variables[name].get())
        except ValueError as error:
            raise ValidationError(f"{label} must be a number.") from error
        if not np.isfinite(value):
            raise ValidationError(f"{label} must be finite.")
        return value

    def _read_force_config(self) -> ForceConfig:
        return ForceConfig(
            kind=ForceKind(self.variables["force_kind"].get()),
            offset=self._number("offset", "Force offset"),
            amplitude=self._number("amplitude", "Force amplitude"),
            frequency=self._number("frequency", "Frequency"),
            phase_deg=self._number("phase", "Phase"),
            tau=self._number("tau", "Time constant"),
            pulse_start=self._number("pulse_start", "Pulse start"),
            pulse_duration=self._number("pulse_duration", "Pulse duration"),
        )

    def read_config(self) -> SimulationConfig:
        spring_kind = SpringKind(self.variables["spring_kind"].get())
        damper_kind = DamperKind(self.variables["damper_kind"].get())
        samples_value = self._number("samples", "Output samples")
        if not samples_value.is_integer():
            raise ValidationError("Output samples must be a whole number.")
        return SimulationConfig(
            force=self._read_force_config(),
            spring=SpringLaw(
                kind=spring_kind,
                k=self._number("k", "Spring constant k"),
                k3=self._number("k3", "Cubic spring constant k3") if spring_kind is SpringKind.HARDENING else 0.0,
            ),
            damper=DamperLaw(
                kind=damper_kind,
                b=self._number("b", "Damping constant b"),
                exponent=self._number("exponent", "Power exponent n") if damper_kind is DamperKind.POWER_LAW else 1.0,
            ),
            initial_extension=self._number("initial_extension", "Initial extension"),
            duration=self._number("duration", "Duration"),
            samples=int(samples_value),
        )

    def run_simulation(self) -> None:
        self.stop_playback()
        try:
            config = self.read_config()
            self.status_var.set("Computing simulation…")
            self.update_idletasks()
            result = simulate(config)
        except (ValidationError, ValueError) as error:
            self.status_var.set("Input error")
            messagebox.showerror("Cannot run simulation", str(error), parent=self)
            return
        self.result = result
        self.force_equation_var.set(force_equation(config.force))
        self.time_scale.configure(to=max(0, len(result.time) - 1))
        self.time_var.set(0)
        self.current_index = 0
        self._draw_dynamics(result)
        self._draw_energy(result)
        self.set_time_index(0)
        residual = result.normalized_balance_error
        self.status_var.set(
            f"Simulation complete: {len(result.time):,} samples; normalized energy residual {residual:.2e}"
        )

    def _style_axis(self, axis, ylabel: str, xlabel: str | None = None) -> None:
        axis.set_ylabel(ylabel, color=COLORS["ink"])
        if xlabel:
            axis.set_xlabel(xlabel, color=COLORS["ink"])
        axis.grid(True, color=COLORS["grid"], linewidth=0.8, alpha=0.8)
        axis.spines[["top", "right"]].set_visible(False)
        axis.tick_params(colors=COLORS["muted"], labelsize=9)

    def _draw_dynamics(self, result: SimulationResult) -> None:
        self.dynamics_figure.clear()
        axes = self.dynamics_figure.subplots(3, 1, sharex=True)
        axes[0].plot(result.time, result.applied_force, color=COLORS["orange"], linewidth=1.8)
        axes[1].plot(result.time, result.extension, color=COLORS["blue"], linewidth=1.8)
        axes[2].plot(result.time, result.velocity, color=COLORS["teal"], linewidth=1.8)
        self._style_axis(axes[0], "Force (N)")
        self._style_axis(axes[1], "Extension (m)")
        self._style_axis(axes[2], "Velocity (m/s)", "Time (s)")
        axes[0].set_title("Time-dependent response", loc="left", fontsize=13, fontweight="bold", color=COLORS["navy"])
        self.dynamics_canvas.draw_idle()

    def _draw_energy(self, result: SimulationResult) -> None:
        self.energy_figure.clear()
        axes = self.energy_figure.subplots(2, 1, sharex=True, gridspec_kw={"height_ratios": [3, 1]})
        top, residual = axes
        top.plot(result.time, result.input_work, label="Applied work  Wᵢₙ", color=COLORS["blue"], linewidth=2.0)
        top.plot(result.time, result.stored_energy_change, label="Spring energy change  ΔUₛ", color=COLORS["teal"], linewidth=1.8)
        top.plot(result.time, result.dissipated_energy, label="Damping dissipation  Eᴅ", color=COLORS["orange"], linewidth=1.8)
        self._style_axis(top, "Energy (J)")
        top.legend(loc="best", frameon=False, fontsize=9)
        top.set_title("Energy conversion and dissipation", loc="left", fontsize=13, fontweight="bold", color=COLORS["navy"])
        residual.plot(result.time, result.balance_error, color=COLORS["red"], linewidth=1.3)
        residual.axhline(0.0, color=COLORS["muted"], linewidth=0.8)
        self._style_axis(residual, "Residual (J)", "Time (s)")
        self.energy_canvas.draw_idle()

    def _timeline_changed(self, value: str) -> None:
        if self.result is None:
            return
        self.set_time_index(int(round(float(value))))

    def set_time_index(self, index: int) -> None:
        if self.result is None:
            return
        index = min(max(index, 0), len(self.result.time) - 1)
        self.current_index = index
        if abs(self.time_var.get() - index) > 0.5:
            self.time_var.set(index)
        result = self.result
        self.time_label.configure(text=f"t = {result.time[index]:.3f} s")
        values = {
            "force": f"{result.applied_force[index]:.4g} N",
            "extension": f"{result.extension[index]:.4g} m",
            "velocity": f"{result.velocity[index]:.4g} m/s",
            "stored": f"{result.stored_energy[index]:.4g} J",
            "dissipated": f"{result.dissipated_energy[index]:.4g} J",
            "work": f"{result.input_work[index]:.4g} J",
        }
        for key, text in values.items():
            self.readout_labels[key].configure(text=text)
        self.balance_var.set(
            "Energy check: Wᵢₙ − ΔUₛ − Eᴅ = "
            f"{result.balance_error[index]:.3e} J"
        )
        self._draw_schematic(index)

    def _draw_schematic(self, index: int) -> None:
        canvas = self.schematic
        canvas.delete("all")
        width = max(canvas.winfo_width(), 720)
        height = max(canvas.winfo_height(), 260)
        wall_x = 80
        neutral_x = int(width * 0.66)
        if self.result is None:
            extension = force = 0.0
            scale = 1.0
        else:
            extension = float(self.result.extension[index])
            force = float(self.result.applied_force[index])
            scale = max(float(np.max(np.abs(self.result.extension))), 1e-9)
        connector_x = int(neutral_x + 0.17 * width * extension / scale)
        connector_x = min(max(connector_x, int(width * 0.42)), int(width * 0.83))

        canvas.create_line(wall_x, 35, wall_x, height - 35, width=5, fill=COLORS["ink"])
        for y in range(42, height - 30, 18):
            canvas.create_line(wall_x - 18, y + 12, wall_x, y - 4, width=2, fill=COLORS["muted"])

        spring_y = 92
        start_x = wall_x
        lead = 35
        canvas.create_line(start_x, spring_y, start_x + lead, spring_y, width=2, fill=COLORS["navy"])
        points = [(start_x + lead, spring_y)]
        zig_start = start_x + lead
        zig_end = connector_x - 18
        segments = 12
        for segment in range(1, segments):
            x = zig_start + (zig_end - zig_start) * segment / segments
            y = spring_y + (15 if segment % 2 else -15)
            points.append((x, y))
        points.append((zig_end, spring_y))
        flat_points = [coordinate for point in points for coordinate in point]
        canvas.create_line(*flat_points, width=2.5, fill=COLORS["blue"], smooth=False)
        canvas.create_line(zig_end, spring_y, connector_x, spring_y, width=2, fill=COLORS["navy"])

        damper_y = 175
        canvas.create_line(wall_x, damper_y, wall_x + 60, damper_y, width=2, fill=COLORS["navy"])
        body_left = wall_x + 60
        body_right = min(wall_x + 145, connector_x - 50)
        canvas.create_rectangle(body_left, damper_y - 24, body_right, damper_y + 24, outline=COLORS["teal"], width=2)
        piston_x = body_right - 18
        canvas.create_line(piston_x, damper_y - 19, piston_x, damper_y + 19, width=3, fill=COLORS["teal"])
        canvas.create_line(piston_x, damper_y, connector_x, damper_y, width=2, fill=COLORS["navy"])

        canvas.create_line(connector_x, 67, connector_x, 200, width=5, fill=COLORS["ink"])
        arrow_length = 70 if force >= 0 else -70
        canvas.create_line(connector_x, 48, connector_x + arrow_length, 48, arrow="last", width=3, fill=COLORS["orange"])
        canvas.create_text(connector_x + arrow_length / 2, 28, text=f"F(t) = {force:.3g} N", fill=COLORS["orange"], font=("Arial", 11, "bold"))
        canvas.create_line(neutral_x, 215, neutral_x, 235, dash=(3, 3), fill=COLORS["muted"])
        canvas.create_line(neutral_x, 226, connector_x, 226, arrow="both", fill=COLORS["blue"], width=2)
        canvas.create_text((neutral_x + connector_x) / 2, 246, text=f"x = {extension:.4g} m", fill=COLORS["blue"], font=("Arial", 10, "bold"))
        canvas.create_text(18, spring_y, text="spring", angle=90, fill=COLORS["muted"], font=("Arial", 9))
        canvas.create_text(32, damper_y, text="damper", angle=90, fill=COLORS["muted"], font=("Arial", 9))

    def toggle_play(self) -> None:
        if self.result is None:
            return
        if self.playing:
            self.stop_playback()
        else:
            if self.current_index >= len(self.result.time) - 1:
                self.set_time_index(0)
            self.playing = True
            self.play_button.configure(text="❚❚ Pause")
            self._advance_animation()

    def _advance_animation(self) -> None:
        if not self.playing or self.result is None:
            return
        jump = max(1, len(self.result.time) // 300)
        next_index = self.current_index + jump
        if next_index >= len(self.result.time):
            self.set_time_index(len(self.result.time) - 1)
            self.stop_playback()
            return
        self.set_time_index(next_index)
        self.play_job = self.after(30, self._advance_animation)

    def stop_playback(self) -> None:
        self.playing = False
        self.play_button.configure(text="▶ Play")
        if self.play_job is not None:
            try:
                self.after_cancel(self.play_job)
            except tk.TclError:
                pass
            self.play_job = None

    def _run_label(self, result: SimulationResult) -> str:
        config = result.config
        number = len(self.comparison_runs) + 1
        nonlinear = "" if config.spring.kind is SpringKind.LINEAR else f", k₃={config.spring.k3:g}"
        damper = f"b={config.damper.b:g}" if config.damper.kind is DamperKind.LINEAR else f"b={config.damper.b:g}, n={config.damper.exponent:g}"
        return f"{number}: k={config.spring.k:g}{nonlinear}; {damper}; {config.force.kind.value}"

    def add_comparison(self) -> None:
        if self.result is None:
            messagebox.showinfo("No simulation", "Run a simulation before adding a comparison.", parent=self)
            return
        if len(self.comparison_runs) >= 6:
            messagebox.showinfo("Comparison limit", "Clear a run before adding more than six cases.", parent=self)
            return
        self.comparison_runs.append((self._run_label(self.result), self.result))
        self._draw_comparisons()
        self.notebook.select(3)
        self.status_var.set(f"Added comparison run {len(self.comparison_runs)} of 6")

    def clear_comparisons(self) -> None:
        self.comparison_runs.clear()
        self._draw_comparisons()
        self.status_var.set("Comparison runs cleared")

    def _draw_comparisons(self) -> None:
        self.compare_figure.clear()
        axes = self.compare_figure.subplots(2, 1, sharex=False)
        colors = [COLORS["blue"], COLORS["orange"], COLORS["teal"], COLORS["red"], COLORS["gold"], COLORS["navy"]]
        for color, (label, result) in zip(colors, self.comparison_runs):
            axes[0].plot(result.time, result.extension, label=label, color=color, linewidth=1.7)
            axes[1].plot(result.time, result.dissipated_energy, label=label, color=color, linewidth=1.7)
        self._style_axis(axes[0], "Extension (m)", "Time (s)")
        self._style_axis(axes[1], "Dissipated energy (J)", "Time (s)")
        axes[0].set_title("Parameter study", loc="left", fontsize=13, fontweight="bold", color=COLORS["navy"])
        if self.comparison_runs:
            for axis in axes:
                axis.legend(loc="best", frameon=False, fontsize=8)
        else:
            axes[0].text(0.5, 0.5, "Run a case and choose Add comparison", ha="center", va="center", transform=axes[0].transAxes, color=COLORS["muted"])
        self.compare_canvas.draw_idle()

    def export_csv(self) -> None:
        if self.result is None:
            messagebox.showinfo("No data", "Run a simulation before exporting data.", parent=self)
            return
        path = filedialog.asksaveasfilename(
            parent=self,
            title="Export simulation data",
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            initialfile="spring_damper_results.csv",
        )
        if not path:
            return
        try:
            with Path(path).open("w", newline="", encoding="utf-8") as handle:
                writer = csv.writer(handle)
                writer.writerow(CSV_COLUMNS)
                writer.writerows(result_rows(self.result))
        except OSError as error:
            messagebox.showerror("Export failed", str(error), parent=self)
            return
        self.status_var.set(f"Saved data to {path}")

    def export_plot(self) -> None:
        selected = self.notebook.index(self.notebook.select())
        if selected == 2:
            figure = self.energy_figure
            initial = "spring_damper_energy.png"
        elif selected == 3:
            figure = self.compare_figure
            initial = "spring_damper_comparison.png"
        else:
            figure = self.dynamics_figure
            initial = "spring_damper_dynamics.png"
        path = filedialog.asksaveasfilename(
            parent=self,
            title="Save plot",
            defaultextension=".png",
            filetypes=[("PNG image", "*.png"), ("PDF document", "*.pdf")],
            initialfile=initial,
        )
        if not path:
            return
        try:
            figure.savefig(path, dpi=220, bbox_inches="tight", facecolor="white")
        except OSError as error:
            messagebox.showerror("Save failed", str(error), parent=self)
            return
        self.status_var.set(f"Saved plot to {path}")

    def _close(self) -> None:
        self.stop_playback()
        self.destroy()


def main() -> None:
    app = SpringDamperApp()
    app.mainloop()


if __name__ == "__main__":
    main()
