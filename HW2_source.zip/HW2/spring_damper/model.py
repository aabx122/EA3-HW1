"""Physics model for a massless parallel spring-damper teaching module.

The connector has no inertia, so force balance is algebraic at every instant:

    applied force = spring force + damper force

That relation gives connector velocity from the current extension and applied
force.  Extension, applied work, and damping dissipation are integrated with a
fourth-order Runge-Kutta scheme.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable

import numpy as np


class ValidationError(ValueError):
    """Raised when a simulation input is outside the supported domain."""


class ForceKind(str, Enum):
    CONSTANT = "Constant"
    SINUSOIDAL = "Sinusoidal"
    SQUARE = "Square wave"
    DECAYING = "Decaying transient"
    SMOOTH_STEP = "Smooth step"
    PULSE = "Finite pulse"


class SpringKind(str, Enum):
    LINEAR = "Linear"
    HARDENING = "Hardening cubic"


class DamperKind(str, Enum):
    LINEAR = "Linear"
    POWER_LAW = "Power law"


@dataclass(frozen=True)
class ForceConfig:
    kind: ForceKind = ForceKind.SINUSOIDAL
    offset: float = 3.0
    amplitude: float = 5.0
    frequency: float = 0.5
    phase_deg: float = 0.0
    tau: float = 1.5
    pulse_start: float = 1.0
    pulse_duration: float = 2.0


@dataclass(frozen=True)
class SpringLaw:
    kind: SpringKind = SpringKind.LINEAR
    k: float = 12.0
    k3: float = 0.0


@dataclass(frozen=True)
class DamperLaw:
    kind: DamperKind = DamperKind.LINEAR
    b: float = 3.0
    exponent: float = 1.0


@dataclass(frozen=True)
class SimulationConfig:
    force: ForceConfig = ForceConfig()
    spring: SpringLaw = SpringLaw()
    damper: DamperLaw = DamperLaw()
    initial_extension: float = 0.0
    duration: float = 10.0
    samples: int = 1601


@dataclass(frozen=True)
class SimulationResult:
    config: SimulationConfig
    time: np.ndarray
    applied_force: np.ndarray
    extension: np.ndarray
    velocity: np.ndarray
    spring_force: np.ndarray
    damper_force: np.ndarray
    stored_energy: np.ndarray
    stored_energy_change: np.ndarray
    input_work: np.ndarray
    dissipated_energy: np.ndarray
    balance_error: np.ndarray

    @property
    def normalized_balance_error(self) -> float:
        scale = max(
            1.0,
            float(np.max(np.abs(self.input_work))),
            float(np.max(np.abs(self.stored_energy_change))),
            float(np.max(np.abs(self.dissipated_energy))),
        )
        return float(np.max(np.abs(self.balance_error))) / scale


def _require_finite(name: str, values: Iterable[float]) -> None:
    if not all(np.isfinite(float(value)) for value in values):
        raise ValidationError(f"{name} must contain only finite values.")


def validate_config(config: SimulationConfig) -> None:
    """Validate model parameters and reject unsupported constitutive laws."""

    _require_finite(
        "Force parameters",
        (
            config.force.offset,
            config.force.amplitude,
            config.force.frequency,
            config.force.phase_deg,
            config.force.tau,
            config.force.pulse_start,
            config.force.pulse_duration,
        ),
    )
    _require_finite("Spring parameters", (config.spring.k, config.spring.k3))
    _require_finite("Damper parameters", (config.damper.b, config.damper.exponent))
    _require_finite("Simulation parameters", (config.initial_extension, config.duration))

    if config.force.frequency < 0:
        raise ValidationError("Frequency must be zero or positive.")
    if config.force.tau <= 0:
        raise ValidationError("The force time constant must be positive.")
    if config.force.pulse_start < 0:
        raise ValidationError("Pulse start time cannot be negative.")
    if config.force.pulse_duration <= 0:
        raise ValidationError("Pulse duration must be positive.")
    if config.spring.k <= 0:
        raise ValidationError("Spring constant k must be positive.")
    if config.spring.k3 < 0:
        raise ValidationError("Cubic spring constant k3 must be zero or positive.")
    if config.spring.kind is SpringKind.LINEAR and config.spring.k3 != 0:
        raise ValidationError("A linear spring must use k3 = 0.")
    if config.damper.b <= 0:
        raise ValidationError("Damping constant b must be positive.")
    if config.damper.exponent <= 0:
        raise ValidationError("Damper exponent n must be positive.")
    if config.damper.kind is DamperKind.LINEAR and config.damper.exponent != 1:
        raise ValidationError("A linear damper must use exponent n = 1.")
    if config.duration <= 0:
        raise ValidationError("Simulation duration must be positive.")
    if not isinstance(config.samples, (int, np.integer)) or config.samples < 101:
        raise ValidationError("Number of samples must be an integer of at least 101.")
    if config.samples > 20001:
        raise ValidationError("Number of samples cannot exceed 20,001.")


def evaluate_force(time: float | np.ndarray, config: ForceConfig) -> float | np.ndarray:
    """Evaluate one of the deliberately bounded applied-force families."""

    t = np.asarray(time, dtype=float)
    if config.kind is ForceKind.CONSTANT:
        result = np.full_like(t, config.offset, dtype=float)
    elif config.kind is ForceKind.SINUSOIDAL:
        phase = np.deg2rad(config.phase_deg)
        result = config.offset + config.amplitude * np.sin(2 * np.pi * config.frequency * t + phase)
    elif config.kind is ForceKind.SQUARE:
        phase = np.deg2rad(config.phase_deg)
        wave = np.where(np.sin(2 * np.pi * config.frequency * t + phase) >= 0.0, 1.0, -1.0)
        result = config.offset + config.amplitude * wave
    elif config.kind is ForceKind.DECAYING:
        result = config.offset + config.amplitude * np.exp(-np.maximum(t, 0.0) / config.tau)
    elif config.kind is ForceKind.SMOOTH_STEP:
        result = config.offset + config.amplitude * (1.0 - np.exp(-np.maximum(t, 0.0) / config.tau))
    elif config.kind is ForceKind.PULSE:
        active = (t >= config.pulse_start) & (t <= config.pulse_start + config.pulse_duration)
        result = config.offset + config.amplitude * active.astype(float)
    else:  # pragma: no cover - Enum prevents this through the public API.
        raise ValidationError(f"Unsupported force type: {config.kind}")
    if np.ndim(time) == 0:
        return float(result)
    return result


def force_equation(config: ForceConfig) -> str:
    """Return a readable expression for display in the teaching interface."""

    f = config
    if f.kind is ForceKind.CONSTANT:
        return f"F(t) = {f.offset:g}"
    if f.kind is ForceKind.SINUSOIDAL:
        return f"F(t) = {f.offset:g} + {f.amplitude:g} sin(2π·{f.frequency:g}t + {f.phase_deg:g}°)"
    if f.kind is ForceKind.SQUARE:
        return f"F(t) = {f.offset:g} + {f.amplitude:g} square(2π·{f.frequency:g}t + {f.phase_deg:g}°)"
    if f.kind is ForceKind.DECAYING:
        return f"F(t) = {f.offset:g} + {f.amplitude:g} exp(-t/{f.tau:g})"
    if f.kind is ForceKind.SMOOTH_STEP:
        return f"F(t) = {f.offset:g} + {f.amplitude:g}[1 - exp(-t/{f.tau:g})]"
    return (
        f"F(t) = {f.offset:g} + {f.amplitude:g} during "
        f"{f.pulse_start:g} ≤ t ≤ {f.pulse_start + f.pulse_duration:g}"
    )


def spring_force(extension: float | np.ndarray, law: SpringLaw) -> float | np.ndarray:
    x = np.asarray(extension, dtype=float)
    cubic = law.k3 if law.kind is SpringKind.HARDENING else 0.0
    result = law.k * x + cubic * x**3
    return float(result) if np.ndim(extension) == 0 else result


def spring_energy(extension: float | np.ndarray, law: SpringLaw) -> float | np.ndarray:
    x = np.asarray(extension, dtype=float)
    cubic = law.k3 if law.kind is SpringKind.HARDENING else 0.0
    result = 0.5 * law.k * x**2 + 0.25 * cubic * x**4
    return float(result) if np.ndim(extension) == 0 else result


def damper_velocity(force: float | np.ndarray, law: DamperLaw) -> float | np.ndarray:
    q = np.asarray(force, dtype=float)
    exponent = law.exponent if law.kind is DamperKind.POWER_LAW else 1.0
    result = np.sign(q) * (np.abs(q) / law.b) ** (1.0 / exponent)
    return float(result) if np.ndim(force) == 0 else result


def damper_force(velocity: float | np.ndarray, law: DamperLaw) -> float | np.ndarray:
    v = np.asarray(velocity, dtype=float)
    exponent = law.exponent if law.kind is DamperKind.POWER_LAW else 1.0
    result = law.b * np.sign(v) * np.abs(v) ** exponent
    return float(result) if np.ndim(velocity) == 0 else result


def _rates(time: float, state: np.ndarray, config: SimulationConfig) -> np.ndarray:
    extension = float(state[0])
    applied = float(evaluate_force(time, config.force))
    elastic = float(spring_force(extension, config.spring))
    viscous = applied - elastic
    velocity = float(damper_velocity(viscous, config.damper))
    return np.array((velocity, applied * velocity, viscous * velocity), dtype=float)


def _rk4_step(time: float, state: np.ndarray, step: float, config: SimulationConfig) -> np.ndarray:
    k1 = _rates(time, state, config)
    k2 = _rates(time + step / 2, state + step * k1 / 2, config)
    k3 = _rates(time + step / 2, state + step * k2 / 2, config)
    k4 = _rates(time + step, state + step * k3, config)
    return state + step * (k1 + 2 * k2 + 2 * k3 + k4) / 6


def _internal_step_limit(config: SimulationConfig) -> float:
    """Choose a conservative RK4 step from a linearized relaxation time."""

    force_scale = abs(config.force.offset) + abs(config.force.amplitude)
    extension_scale = max(abs(config.initial_extension), force_scale / config.spring.k, 1e-6)
    effective_k = config.spring.k
    if config.spring.kind is SpringKind.HARDENING:
        effective_k += 3.0 * config.spring.k3 * extension_scale**2
    relaxation_time = config.damper.b / max(effective_k, 1e-12)
    return max(1e-7, 0.08 * relaxation_time)


def simulate(config: SimulationConfig) -> SimulationResult:
    """Simulate the connector motion and energy flows for ``config``."""

    validate_config(config)
    time = np.linspace(0.0, config.duration, config.samples)
    state = np.array((config.initial_extension, 0.0, 0.0), dtype=float)
    states = np.empty((config.samples, 3), dtype=float)
    states[0] = state
    limit = _internal_step_limit(config)

    for index in range(1, config.samples):
        start = float(time[index - 1])
        interval = float(time[index] - start)
        substeps = max(1, int(np.ceil(interval / limit)))
        if substeps > 2000:
            raise ValidationError(
                "These parameters create an extremely short relaxation time. "
                "Increase b, reduce k or k3, or shorten the simulation."
            )
        step = interval / substeps
        for substep in range(substeps):
            state = _rk4_step(start + substep * step, state, step, config)
            if not np.all(np.isfinite(state)):
                raise ValidationError(
                    "The numerical solution became non-finite. Try a larger damping constant "
                    "or less extreme nonlinear parameters."
                )
        states[index] = state

    extension = states[:, 0]
    input_work = states[:, 1]
    dissipated = states[:, 2]
    applied = np.asarray(evaluate_force(time, config.force), dtype=float)
    elastic = np.asarray(spring_force(extension, config.spring), dtype=float)
    viscous = applied - elastic
    velocity = np.asarray(damper_velocity(viscous, config.damper), dtype=float)
    stored = np.asarray(spring_energy(extension, config.spring), dtype=float)
    stored_change = stored - stored[0]
    residual = input_work - stored_change - dissipated

    return SimulationResult(
        config=config,
        time=time,
        applied_force=applied,
        extension=extension,
        velocity=velocity,
        spring_force=elastic,
        damper_force=viscous,
        stored_energy=stored,
        stored_energy_change=stored_change,
        input_work=input_work,
        dissipated_energy=dissipated,
        balance_error=residual,
    )


CSV_COLUMNS = (
    "time_s",
    "applied_force_N",
    "extension_m",
    "velocity_m_per_s",
    "spring_force_N",
    "damper_force_N",
    "stored_energy_J",
    "stored_energy_change_J",
    "input_work_J",
    "dissipated_energy_J",
    "balance_error_J",
)


def result_rows(result: SimulationResult):
    """Yield rows in the same order as ``CSV_COLUMNS``."""

    return zip(
        result.time,
        result.applied_force,
        result.extension,
        result.velocity,
        result.spring_force,
        result.damper_force,
        result.stored_energy,
        result.stored_energy_change,
        result.input_work,
        result.dissipated_energy,
        result.balance_error,
    )
